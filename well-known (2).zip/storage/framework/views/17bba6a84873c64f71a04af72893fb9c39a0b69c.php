<?php $__env->startSection('content'); ?>
<div class="form-element-area">
       <div class="container">
         <form action="<?php echo e(route('setting.update')); ?>" method="post" enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>


           <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <div class="form-element-list">
                       <div class="basic-tb-hd">
                           <h2>All Settings </h2>
                         </div>

                         <div class="row">
                             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="form-group float-lb">
                                     <div class="nk-int-st" >
                                          <a href="#"><img style="background-color: #00c292;" src="<?php echo e(asset($settings->logo)); ?>" alt="" /></a>
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <div class="row">
                             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="form-group float-lb">
                                     <div class="nk-int-st">
                                         <input name="logo" type="file" value="<?php echo e($settings->logo); ?>" class="form-control">
                                         <input name="id" type="hidden" value="<?php echo e($settings->id); ?>" class="form-control">
                                     </div>
                                 </div>
                             </div>
                         </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="header1" value="<?php echo e($settings->header1); ?>" class="form-control"><br/>
                                       <label style="top: -14px;" class="nk-label">Bold Heading</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="header2" value="<?php echo e($settings->header2); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Small Heading</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="facebook" value="<?php echo e($settings->facebook); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Facebook Link</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="youtube" value="<?php echo e($settings->youtube); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Youtube Link</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="twitter" value="<?php echo e($settings->twitter); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Twitter Lingk</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="gmail" value="<?php echo e($settings->gmail); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Gmail</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="phone" value="<?php echo e($settings->phone); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Phone Number</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div class="row">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                               <div class="form-group float-lb">
                                   <div class="nk-int-st">
                                       <input type="text" name="address" value="<?php echo e($settings->address); ?>" class="form-control">
                                       <label style="top: -14px;" class="nk-label">Address</label>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <div class="form-group">
                                  <div class="nk-int-st">
                                      <textarea style=" padding-left: 21px;" name="description" class="form-control" rows="5"><?php echo e($settings->description); ?></textarea>

                                  </div>
                              </div>
                          </div>
                      </div>
                   <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <div class="form-group">
                                  <div class="nk-int-st">
                                      <textarea name="footer"  style=" padding-left: 21px;" class="form-control" rows="5"><?php echo e($settings->footer); ?></textarea>

                                  </div>
                              </div>
                          </div>
                      </div>
                   <div class="row"  style="float:right;">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="float:right;">
                             <div class="form-example-int">
                                 <button class="btn btn-success notika-btn-success">Update</button>
                             </div>
                         </div>
                      </div>
               </div>
           </div>

        </form>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/admin/setting.blade.php ENDPATH**/ ?>