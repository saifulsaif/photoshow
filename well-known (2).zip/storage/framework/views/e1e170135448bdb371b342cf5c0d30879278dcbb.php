
<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<section>
		<div class="block gray remove-top">
			<div class="row">
				<div class="col-md-12">
					<div class="list-detail-sec">
						<ul class="list-detail-carousel" id="listing-detail-carousel">
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld1.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
											<form action="<?php echo e(route('search.photo')); ?>" method="post" enctype="multipart/form-data">
													 <?php echo e(csrf_field()); ?>

				                <div class="field"><input name="keyword" type="text" placeholder="Keywords"></div>

				                <div class="field">
				                  <select data-placeholder="All Categories" name="category" class="chosen-select" tabindex="2">
				                          <option value="">All Categories</option>
																	<?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 																 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
 																 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                      </select>
				                </div>
				                <div class="field">
				                  <button type="submit"><i class="la la-search"></i>SEARCH</button>
				                </div>
				              </form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld2.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
											<form action="<?php echo e(route('search.photo')); ?>" method="post" enctype="multipart/form-data">
													 <?php echo e(csrf_field()); ?>

				                <div class="field"><input type="text" name="keyword" placeholder="Keywords"></div>

				                <div class="field">
				                  <select data-placeholder="All Categories" name="category" class="chosen-select" tabindex="2">
				                          <option value="All Categories">All Categories</option>
																	<option value="All Categories">All Categories</option>
																	<?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
																 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                      </select>
				                </div>
				                <div class="field">
				                  <button type="submit"><i class="la la-search"></i>SEARCH</button>
				                </div>
				              </form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld3.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
											<form action="<?php echo e(route('search.photo')); ?>" method="post" enctype="multipart/form-data">
													 <?php echo e(csrf_field()); ?>

												<div class="field"><input type="text" name="keyword" placeholder="Keywords"></div>

												<div class="field">
													<select data-placeholder="All Categories" name="category" class="chosen-select" tabindex="2">
																	<option value="All Categories">All Categories</option>
																	<?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
																 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</select>
												</div>
												<div class="field">
													<button type="submit"><i class="la la-search"></i>SEARCH</button>
												</div>
											</form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
						</ul>
						<div class="mian-listing-detail">
							<div class="container-flud">
								<div class="row">
									<div class="col-md-12 column">
										<?php if(auth()->guard()->guest()): ?>
										<div class="filter-bar">
											<span style="color: #1c2027;float: left;font-family: Roboto;font-size: 24px;margin: 11px 0;font-weight: 500;">Free Download Photos </span>
										</div>
										<?php else: ?>
										<div class="filter-bar">
											<span> You have
												<?php $i=0; ?>
													<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php $i++; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php echo e($i); ?>

												 photos here.</span>
											<div class="open-filter-btns">
												<span class="close-filter"><i class="la la-close"></i> Close</span>
												<span class="open-filter"><i class="la la-camera"></i>Upload</span>
											</div>
											<div class="side-search-form with-filters">
												<form action="<?php echo e(route('search.photo')); ?>" method="post" enctype="multipart/form-data">
														 <?php echo e(csrf_field()); ?>

													<div class="row">
														<div class="col-md-4">
															<select data-placeholder="All Locations" name="category_id" class="chosen-select" tabindex="2">
																			<option value="All Locations">Select Category</option>
																			<option value="1">hotel</option>
																	</select>
														</div>
														<div class="col-md-4">
															<input type="text" name="title" class="input-style" placeholder="Image Title" />
														</div>
														<div class="col-md-4">
															<input type="file" name="photo" class="input-style" placeholder="Image Title" />
														</div>
														<div class="col-md-12">

														</div>
														<div class="col-md-12">
															<button type="submit">Upload</button>
														</div>
													</div>
												</form>
											</div>
										</div>
										<?php endif; ?>
										<div class="row" style="margin-tor:30px;">
										 <div class="do-tonight-sec">
											 <div class="row">
											 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														 <div class="col-md-3">
															 <div class="dt-box">
																 <a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" /></a>
																 <span><?php echo e($photo->title); ?></span>
															 </div>
														 </div>
														 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											 </div>
											 <!-- <div class="row">
														 <div class="col-md-3">
														 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															 <div class="dt-box">
																 <a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" /><span><?php echo e($photo->title); ?></span></a>
															 </div>
															 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														 </div>
														 <div class="col-md-3">
														 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															 <div class="dt-box">
																 <a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" /><span><?php echo e($photo->title); ?></span></a>
															 </div>
															 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														 </div>
														 <div class="col-md-3">
														 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															 <div class="dt-box">
																 <a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" /><span><?php echo e($photo->title); ?></span></a>
															 </div>
															 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														 </div>
														 <div class="col-md-3">
														 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															 <div class="dt-box">
																 <a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" /><span><?php echo e($photo->title); ?></span></a>
															 </div>
															 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														 </div>
											 </div> -->
										 </div>
									 </div>
									</div>
								</div>
								<div class="pagination">

									<ul>
											<span style="color:red;"><?php echo e($photos->links()); ?></span>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/freedownload/public_html/resources/views/fontend/photo.blade.php ENDPATH**/ ?>