<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<section>
		<div class="block no-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="inner-header">
							<h2>Edit Profile</h2>
							<ul class="breadcrumbs">
								<li><a href="#" title="">Home</a></li>
								<li><a href="#" title="">Page</a></li>
								<li>Edit Profile</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray">
			<div class="container">
				<div class="row">
					<?php if(Session::has('success')): ?>
					  <div class="alert alert-success">
					    <p><?php echo e(Session::get('success')); ?></p>
					  </div>
					<?php endif; ?>
					<div class="col-md-10 col-md-offset-1">
						<div class="edit-profile-sec">
							<form action="<?php echo e(route('update.profile.info')); ?>" method="post" enctype="multipart/form-data">
								<?php echo e(csrf_field()); ?>

								<div class="form-profile">
									<div class="row">
										<div class="col-md-12">
											<div class="change-my-dp">
												<img src="<?php echo e($profile->photo); ?>" alt="" />
													<input type="file" placeholder="First Name" name="photo" value="<?php echo e($profile->photo); ?>">
											</div>
										</div>
										<div class="col-md-12">
											<h3>About You</h3>
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="First Name" name="first_name" value="<?php echo e($profile->first_name); ?>">
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="Last Name" name="last_name" value="<?php echo e($profile->first_name); ?>">
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="alitfn58@gmail.com" name="email" value="<?php echo e($profile->email); ?>">
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="3032 40302 202" name="number" value="<?php echo e($profile->number); ?>">
										</div>
										<div class="col-md-12">
											<textarea name="description"><?php echo e($profile->description); ?></textarea>
										</div>
										<div class="col-md-12">
											<h3>Social</h3>
										</div>
										<div class="col-md-6">
											<input type="text" placeholder="Facebook" name="facebook" value="<?php echo e($profile->facebook); ?>" />
										</div>
										<div class="col-md-6">
											<input type="text" placeholder="Youtube" name="youtube" value="<?php echo e($profile->youtube); ?>"/>
										</div>
										<div class="col-md-6">
											<input type="text" placeholder="Twitter"name="twitter" value="<?php echo e($profile->twitter); ?>" />
										</div>
										<div class="col-md-6">
											<input type="text" placeholder="Linkedin" name="linkin" value="<?php echo e($profile->linkin); ?>" />
										</div>
										<!-- <div class="col-md-12">
											<h3>Change Your Password</h3>
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="Current Password" />
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="New Password" />
										</div>
										<div class="col-md-12">
											<input type="text" placeholder="Confirm New Password" />
										</div> -->
									</div>
								</div>
								<div class="submission-btns">
									<button type="submit">Save Changes</button>
									<a href="#" title="">Cancel</a>
								</div>
							</form>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/update_profile.blade.php ENDPATH**/ ?>