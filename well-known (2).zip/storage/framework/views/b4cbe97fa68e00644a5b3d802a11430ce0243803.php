<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<section>
	<div class="block gray ">
		<div class="container">
			<div class="row">
				<?php if(Session::has('danger')): ?>
				  <div class="alert alert-danger">
				    <p><?php echo e(Session::get('danger')); ?></p>
				  </div>
				<?php endif; ?>
				<?php if(Session::has('success')): ?>
				  <div class="alert alert-success">
				    <p><?php echo e(Session::get('success')); ?></p>
				  </div>
				<?php endif; ?>
				<div class="col-md-12 column">
					<div class="shoping-detail-sec">
						<div class="row">
							<div class="col-md-4">
								<div class="row">
									<div class="col-md-3 col-ms-4">
										<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php
										$author_photo= \DB::table('Profiles')->where('user_id',$photo->user_id)->first();
										$author_follower= DB::table('Followers')->where('followers',$author_photo->user_id)->get();
										$followers=0;
										foreach($author_follower as $follow){
											$followers++;
										}
										?>
										<!-- <?php echo e(url('/user/profile')); ?>/<?php echo e($author_photo->user_id); ?> -->
										<div class="review-avatar"> <a href="#"> <img style="border-radius: 50%;height: 65px;width: 65px;" src="<?php echo e(asset('/'.$author_photo->photo)); ?>" alt=""> </a></div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="col-md-6 col-ms-4">
										 <h5 style="font-size: 19px;"><?php echo e($author_photo->first_name); ?><?php echo e($author_photo->last_name); ?></h5>
										 <?php if($followers>1000): ?>
                       <?php $followers=($followers/1000); ?>
											 <span><?php echo e($followers); ?>K	 Follows</span>
										 <?php else: ?>
										 <span><?php echo e($followers); ?>  Follows</span>
										 <?php endif; ?>
									</div>
									<div class="col-md-3 col-ms-4">

											<button type="button" id="button" class="follow">Follow</button>

									</div>
								</div>
								<div class="single-product-gallery">
								</div>
							</div>
							<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4">
								<div class="single-product-gallery">
									<ul class="single-product-images">

										<li><img style="padding:9px;" src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" />

										</li>
								  	</ul>

								</div>
							</div>
							<div class="col-md-4">
								<div class="single-product-info-a">
									<a class="download" href="<?php echo e(asset('/'.$photo->photo)); ?>" download title=""><i class="la la-download"></i> 	<span>Free Download</span></a>

								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-12 column">
								<div class="filter-bar">
									<span style="color: #1c2027;float: left;font-family: Roboto;font-size: 24px;margin: 11px 0;font-weight: 500;">Related Photos</span>
								</div>
						<div class="product-sec">
							<div class="products-box">
								<div class="row">
									<?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-3 col-sm-6 col-xs-12">
										<div class="product-box">
											<div class="product-thumb">
												<img src="<?php echo e(asset('/'.$photo->photo)); ?>" alt="" />

											</div>
											<h3><a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><?php echo e($photo->title); ?></a></h3>
										</div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
							<div class="pagination">
								<ul>
									<li class="prev"><a href=""><i class="la  la-arrow-left"></i></a></li>
									<li><a href="">1</a></li>
									<li><a class="active" href="">2</a></li>
									<li><a href="">3</a></li>
									<li><span class="delimeter">...</span></li>
									<li><a href="">22</a></li>
									<li class="next"><a href=""><i class="la  la-arrow-right"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
						</div>
					</div><!-- Shoping Detail Sec -->
				</div>
			</div>
		</div>
	</div>
</section>
<script>
			$(document).on('click', '#button', function(e){
			$.ajax({
				alert('work');

			});
			});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/photo-view.blade.php ENDPATH**/ ?>