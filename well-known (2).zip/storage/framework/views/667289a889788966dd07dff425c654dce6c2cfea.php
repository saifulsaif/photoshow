<header class="on-top">
  <div class="logo"><a href="index.html" title=""><img src="<?php echo e(asset('images/logo/logo.png')); ?>" alt="" /></a></div>
  <div class="menu-sec">


      <?php if(auth()->guard()->guest()): ?>
    <div class="acount-header-btn">
      <ul class="navbar-nav ml-auto">
          <!-- Authentication Links -->
      <span class="login-btn">LogIn</span>
      <span class="register-btn">Register</span>
    </div>
    <?php else: ?>
    <select class="SlectBox">
      <option data-display="Select">	<?php echo e(Auth::user()->name); ?></option>
      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
         onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
        <option href="<?php echo e(route('logout')); ?>" data-display="Select"><?php echo e(__('Logout')); ?></option>
      </a>

      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
      </form>

    </select>
    <?php endif; ?>
    <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();	 document.getElementById('logout-form').submit();" title="" class="add-listing-btn"><i class="la la-plus"></i>Get More Point</a>
    <div class="search-header">
      <span class="open-search"><i class="la la-search"></i><i class="la la-close"></i></span>
      <form>
        <input type="text" placeholder="Search">
      </form>
    </div>
    <nav class="header-menu">
      <ul>
        <li><a href="<?php echo e(route('home')); ?>" title="">Home</a></li>
        <li><a href="#" title="">Photos</a></li>
        <li><a href="#" title="">Videos</a></li>
        <li><a href="<?php echo e(route('promotion')); ?>" title="">Promition</a></li>
        <li><a href="#" title="">About</a></li>
        <li><a href="#" title="">Contact US</a></li>
      </ul>
    </nav>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/indexheader.blade.php ENDPATH**/ ?>