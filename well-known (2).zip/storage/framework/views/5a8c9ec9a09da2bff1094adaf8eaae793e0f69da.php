<footer>
  <div class="block remove-bottom">
    <div data-velocity="-.1" style="background: url(<?php echo e(asset('images/footer.jpg')); ?>) repeat scroll 50% 422.28px transparent;" class="parallax no-parallax scrolly-invisible"></div>
    <div class="container">
      <div class="row">
        <div class="col-md-4 column">
          <div class="widget">
            <h3 class="footer-title">PROLIST THEME</h3>
            <div class="about-widget">
              <p><?php echo e($settings->description); ?></p>
              <ul>
                <li><a href="<?php echo e($settings->facebook); ?>" title=""><i class="la la-twitter"></i></a></li>
                <li><a href="<?php echo e($settings->youtube); ?>" title=""><i class="la la-instagram"></i></a></li>
                <li><a href="#" title=""><i class="la la-pinterest"></i></a></li>
                <li><a href="<?php echo e($settings->twitter); ?>" title=""><i class="la la-google-plus"></i></a></li>
                <li><a href="#" title=""><i class="la la-tumblr "></i></a></li>
              </ul>
            </div>
          </div><!-- Widget -->
        </div>
        <div class="col-md-4 column">
          <div class="widget">
            <h3 class="footer-title">PROLIST CATEGORIES</h3>
            <div class="link-widget">
              <ul>
                <li><a href="#" title="">Food & Drink</a></li>
                <li><a href="#" title="">IT World</a></li>
                <li><a href="#" title="">Money & Finance</a></li>
                <li><a href="#" title="">Movies & Cinemas</a></li>
                <li><a href="#" title="">Sports</a></li>
                <li><a href="#" title="">Music</a></li>
                <li><a href="#" title="">Parties</a></li>
                <li><a href="#" title="">People & Health</a></li>
                <li><a href="#" title="">Seminars</a></li>
                <li><a href="#" title="">Theatres</a></li>
              </ul>
            </div>
          </div><!-- Widget -->
        </div>
        <div class="col-md-4 column">
          <div class="widget">
            <h3 class="footer-title">CONTACT INFORMATION</h3>
            <div class="contact-widget">
              <ul>
                <li>
                  <i class="la la-map"></i>
                  <span>Address</span>
                  <span><?php echo e($settings->address); ?></span>
                </li>
                <li>
                  <i class="la la-mobile"></i>
                  <span>Cell Phone</span>
                  <span><?php echo e($settings->phone); ?></span>
                </li>
                <li>
                  <i class="la la-envelope"></i>
                  <span>E-mail Address</span>
                  <span><a href="mailto:info@prolist.com"><?php echo e($settings->gmail); ?></a>, <a href="mailto:support@prolist.gmail"><?php echo e($settings->gmail); ?></a></span>
                </li>
              </ul>
            </div>
          </div><!-- Widget -->
        </div>
      </div>
    </div>
    <div class="bottom-line">
      <span><?php echo e($settings->footer); ?></span>
    </div>
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/footer.blade.php ENDPATH**/ ?>