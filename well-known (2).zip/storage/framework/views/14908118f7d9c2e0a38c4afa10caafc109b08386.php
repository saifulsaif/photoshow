<div class="responive-header">
  <div class="logo"><a href="<?php echo e(route('home')); ?>" title=""><img src="<?php echo e(asset($settings->logo)); ?>	" alt="" /></a></div>
  <span class="open-responsive-btn"><i class="la la-bars"></i><i class="la la-close"></i></span>
  <div class="resp-btn-sec">
      <?php if(auth()->guard()->guest()): ?>
    <div class="acount-header-btn">
      <span class="register-btn">Register</span>/
      <span class="login-btn">LogIn</span>
    </div>
    <?php else: ?>
    <div class="acount-header-btn">

      <span class="register-btn"><?php echo e(Auth::user()->name); ?></span>
    </div>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
    <a href="add-listing.html" title="" class="view-all-blog"><i class="la la-plus"></i>Free Point</a>
    <?php else: ?>
      <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();	 document.getElementById('logout-form').submit();" title="" class="add-listing-btn"> Point : 55.64</a>
    <?php endif; ?>

    <div class="search-header">
      <span class="open-search"><i class="la la-search"></i><i class="la la-close"></i></span>
      <form>
        <input type="text" placeholder="Search">
      </form>
    </div>
  </div>
  <div class="responisve-menu">
    <span class="close-reposive"><i class="la la-close"></i></span>
    <div class="logo"><a href="<?php echo e(route('home')); ?>" title=""><img src="<?php echo e(asset($settings->logo)); ?>"  alt="" /></a></div>
    <ul>
      <li><a href="<?php echo e(route('home')); ?>" title="">Home</a></li>
      <li><a href="<?php echo e(route('photo')); ?>" title="">Photos</a></li>
      <li><a href="<?php echo e(route('video')); ?>" title="">Videos</a></li>
      <li><a href="<?php echo e(route('promotion')); ?>" title="">Promition</a></li>
      <li><a href="<?php echo e(route('profile')); ?>" title="">Profile</a></li>
      <li><a href="<?php echo e(route('contact')); ?>" title="">Contact US</a></li>
    </ul>
  </div>
</div><!-- Responsive-header -->
<header class="on-top dark">
		<div class="logo"><a href="<?php echo e(route('home')); ?>" title=""><img src="<?php echo e(asset($settings->logo)); ?>" alt="" /></a></div>
		<div class="menu-sec">
      <?php if(auth()->guard()->guest()): ?>
    <div class="acount-header-btn">
      <ul class="navbar-nav ml-auto">
          <!-- Authentication Links -->
      <span class="login-btn">LogIn</span>
      <span class="register-btn">Register</span>
    </div>
    <?php else: ?>
    <select class="SlectBox">
      <option data-display="Select">	<?php echo e(Auth::user()->name); ?></option>

      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
         onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
        <option href="<?php echo e(route('logout')); ?>" data-display="Select"><?php echo e(__('Logout')); ?></option>
      </a>

      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
      </form>

    </select>

    <?php endif; ?>
		<?php if(auth()->guard()->guest()): ?>
		<a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();	 document.getElementById('logout-form').submit();" title="" class="add-listing-btn"><i class="la la-plus"></i> Point : 55.64</a>
		<?php else: ?>
    <?php
    $user_id=Auth::user()->id;
    $profile = DB::table('Profiles')->where('user_id',$user_id)->first();
    $points = DB::table('Points')->where('user_id',$user_id)->first();
    ?>
		<div class="search-header">
		<div class="review-avatar"> <a href="<?php echo e(route('profile')); ?>"><img style="border-radius: 50%;height: 55px;width: 55px;margin-top: 16px;margin-left: 10px" src="<?php echo e($profile->photo); ?>" alt=""></a> </div>
	 </div>
	 <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();	 document.getElementById('logout-form').submit();" title="" class="add-listing-btn"> Point : <?php echo e($points->point); ?></a>
  <?php endif; ?>
			<nav class="header-menu">
        <ul>
          <li><a href="<?php echo e(route('home')); ?>" title="">Home</a></li>
          <li><a href="<?php echo e(route('photo')); ?>" title="">Photos</a></li>
          <li><a href="<?php echo e(route('video')); ?>" title="">Videos</a></li>
          <li><a href="<?php echo e(route('promotion')); ?>" title="">Promition</a></li>
	        <li><a href="<?php echo e(route('profile')); ?>" title="">Profile</a></li>
          <li><a href="<?php echo e(route('contact')); ?>" title="">Contact US</a></li>
        </ul>
			</nav>
		</div>
	</header>
<?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/header.blade.php ENDPATH**/ ?>