<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="creativelayers">

<title>Prolist - Directory Listing HTML Template</title>

<!-- Styles -->
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" /><!-- Bootstrap -->
<link rel="stylesheet" href="css/line-awesome.min.css" type="text/css" /><!-- Icons -->

<link rel="stylesheet" href="css/style.css" type="text/css" /><!-- Style -->
<link rel="stylesheet" href="css/responsive.css" type="text/css" /><!-- Responsive -->
<link rel="stylesheet" href="css/colors/colors.css" type="text/css" /><!-- color -->

<link rel="shortcut icon" type="image/png" href="images/favicon.ico"/>

</head>
<body>
<div class="page-loading">
	<div class="loadery"></div>
</div>
<div class="theme-layout">

	<div class="responive-header">
		<div class="logo"><a href="index.html" title=""><img src="http://placehold.it/97x32		" alt="" /></a></div>
		<span class="open-responsive-btn"><i class="la la-bars"></i><i class="la la-close"></i></span>
		<div class="resp-btn-sec">
			<div class="acount-header-btn">
				<span class="register-btn">Register</span>/
				<span class="login-btn">LogIn</span>
			</div>
			<a href="add-listing.html" title="" class="add-listing-btn"><i class="la la-plus"></i>Add Your Listing</a>
			<div class="search-header">
				<span class="open-search"><i class="la la-search"></i><i class="la la-close"></i></span>
				<form>
					<input type="text" placeholder="Search">
				</form>
			</div>
		</div>
		<div class="responisve-menu">
			<span class="close-reposive"><i class="la la-close"></i></span>
			<div class="logo"><a href="index.html" title=""><img src="http://placehold.it/97x32		" alt="" /></a></div>
			<ul>
				<li class="menu-item-has-children">
					<a href="#" title="">Home</a>
					<ul>
						<li><a href="index.html" title="">Home 1</a></li>
						<li><a href="index2.html" title="">Home 2</a></li>
						<li><a href="index3.html" title="">Home 3</a></li>
						<li><a href="index4.html" title="">Home 4</a></li>
						<li><a href="index5.html" title="">Home 5</a></li>
					</ul>
				</li>
				<li class="menu-item-has-children">
					<a href="#" title="">Listings</a>
					<ul>
						<li><a href="columns-list.html" title="">Column Listings</a></li>
						<li><a href="columns-list2.html" title="">Column Listings 2</a></li>
						<li><a href="left-sidebar-list.html" title="">Left Sidebar List</a></li>
						<li><a href="right-sidebar-list.html" title="">Right Sidebar List</a></li>
						<li><a href="list-view.html" title="">Listing List View</a></li>
						<li><a href="map-list1.html" title="">Map Listing 1</a></li>
						<li><a href="map-list2.html" title="">Map Listing 2</a></li>
						<li><a href="map-list3.html" title="">Map Listing 3</a></li>
						<li><a href="list-detail.html" title="">List Details</a></li>
						<li><a href="list-detail2.html" title="">List Details 2</a></li>
					</ul>
				</li>
				<li class="menu-item-has-children">
					<a href="#" title="">Pages</a>
					<ul>
						<li><a href="my-listing.html" title="">My Listings</a></li>
						<li><a href="add-listing.html" title="">Add Listings</a></li>
						<li><a href="edit-profile.html" title="">Edit Profile</a></li>
						<li><a href="register.html" title="">Register</a></li>
						<li><a href="singin.html" title="">Sign In</a></li>
					</ul>
				</li>
				<li class="menu-item-has-children">
					<a href="#" title="">Extras</a>
					<ul>
						<li><a href="404.html" title="">Error 404</a></li>
						<li><a href="blog.html" title="">Blog</a></li>
						<li><a href="blog2.html" title="">Blog 2</a></li>
						<li><a href="blog-detail.html" title="">Blog Detail</a></li>
						<li><a href="faq.html" title="">FAQ's</a></li>
						<li><a href="how-it-works.html" title="">How it works</a></li>
						<li><a href="pricing.html" title="">Pricings</a></li>
						<li><a href="terms.html" title="">Terms & Condition</a></li>
					</ul>
				</li>
				<li class="menu-item-has-children">
					<a href="#" title="">Shop</a>
					<ul>
						<li><a href="shop.html" title="">Shop</a></li>
						<li><a href="cart.html" title="">Cart</a></li>
						<li><a href="checkout.html" title="">Checkout</a></li>
						<li><a href="shopping-detail.html" title="">Shop Detail</a></li>
					</ul>
				</li>
				<li><a href="contact.html" title="">Contact Us</a></li>
			</ul>
		</div>
	</div><!-- Responsive-header -->

	<header class="on-top">
		<div class="logo"><a href="index.html" title=""><img src="http://placehold.it/97x32		" alt="" /></a></div>
		<div class="menu-sec">
			<select class="SlectBox">
				<option data-display="Select">EN</option>
				<option value="1">TK</option>
				<option value="2">RA</option>
				<option value="3">PK</option>
			</select>
			<div class="acount-header-btn">
				<span class="register-btn">Register</span>/
				<span class="login-btn">LogIn</span>
			</div>
			<a href="add-listing.html" title="" class="add-listing-btn"><i class="la la-plus"></i>Add Your Listing</a>
			<div class="search-header">
				<span class="open-search"><i class="la la-search"></i><i class="la la-close"></i></span>
				<form>
					<input type="text" placeholder="Search">
				</form>
			</div>
			<nav class="header-menu">
				<ul>
					<li class="menu-item-has-children">
						<a href="#" title="">Home</a>
						<ul>
							<li><a href="index.html" title="">Home 1</a></li>
							<li><a href="index2.html" title="">Home 2</a></li>
							<li><a href="index3.html" title="">Home 3</a></li>
							<li><a href="index4.html" title="">Home 4</a></li>
							<li><a href="index5.html" title="">Home 5</a></li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="#" title="">Listings</a>
						<ul>
							<li><a href="columns-list.html" title="">Column Listings</a></li>
							<li><a href="columns-list2.html" title="">Column Listings 2</a></li>
							<li><a href="left-sidebar-list.html" title="">Left Sidebar List</a></li>
							<li><a href="right-sidebar-list.html" title="">Right Sidebar List</a></li>
							<li><a href="list-view.html" title="">Listing List View</a></li>
							<li><a href="map-list1.html" title="">Map Listing 1</a></li>
							<li><a href="map-list2.html" title="">Map Listing 2</a></li>
							<li><a href="map-list3.html" title="">Map Listing 3</a></li>
							<li><a href="list-detail.html" title="">List Details</a></li>
							<li><a href="list-detail2.html" title="">List Details 2</a></li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="#" title="">Pages</a>
						<ul>
							<li><a href="my-listing.html" title="">My Listings</a></li>
							<li><a href="add-listing.html" title="">Add Listings</a></li>
							<li><a href="edit-profile.html" title="">Edit Profile</a></li>
							<li><a href="register.html" title="">Register</a></li>
							<li><a href="singin.html" title="">Sign In</a></li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="#" title="">Extras</a>
						<ul>
							<li><a href="404.html" title="">Error 404</a></li>
							<li><a href="blog.html" title="">Blog</a></li>
							<li><a href="blog2.html" title="">Blog 2</a></li>
							<li><a href="blog-detail.html" title="">Blog Detail</a></li>
							<li><a href="faq.html" title="">FAQ's</a></li>
							<li><a href="how-it-works.html" title="">How it works</a></li>
							<li><a href="pricing.html" title="">Pricings</a></li>
							<li><a href="terms.html" title="">Terms & Condition</a></li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="#" title="">Shop</a>
						<ul>
							<li><a href="shop.html" title="">Shop</a></li>
							<li><a href="cart.html" title="">Cart</a></li>
							<li><a href="checkout.html" title="">Checkout</a></li>
							<li><a href="shopping-detail.html" title="">Shop Detail</a></li>
						</ul>
					</li>
					<li><a href="contact.html" title="">Contact Us</a></li>
				</ul>
			</nav>
		</div>
	</header>

	<section>
		<div class="block no-padding">
			<div class="row">
				<div class="col-md-12">
					<div class="main-featured-sec">
						<ul class="featured-bg-slide">
							<li><img src="http://placehold.it/1600x950" alt="" /></li>
							<li><img src="http://placehold.it/1600x950" alt="" /></li>
							<li><img src="http://placehold.it/1600x950" alt="" /></li>
							<li><img src="http://placehold.it/1600x950" alt="" /></li>
						</ul>
						<div class="mian-featured-area">
							<div class="main-featured-text">
								<h1>Find the Best Places to Be</h1>
								<span>All the top locations – from restaurants and clubs, to cinemas, galleries, and more.</span>
							</div>
							<div class="directory-searcher">
								<form>
									<div class="field"><input type="text" placeholder="Keywords"></div>
									<div class="field">
										<select data-placeholder="All Locations" class="chosen-select" tabindex="2">
								            <option value="All Locations">All Locations</option>
								            <option value="United States">United States</option>
								            <option value="United Kingdom">United Kingdom</option>
								            <option value="Afghanistan">Afghanistan</option>
								            <option value="Aland Islands">Aland Islands</option>
								            <option value="Albania">Albania</option>
								        </select>
									</div>
									<div class="field">
										<select data-placeholder="All Categories" class="chosen-select" tabindex="2">
								            <option value="All Categories">All Categories</option>
								            <option value="Foods">Foods</option>
								            <option value="Lodging">Lodging</option>
								            <option value="Nightlife">Nightlife</option>
								            <option value="AOutdoors">Outdoors</option>
								            <option value="Restaurants">Restaurants</option>
								        </select>
									</div>
									<div class="field">
										<button type="submit"><i class="la la-search"></i>SEARCH</button>
									</div>
								</form>
							</div>
							<div class="cat-lists">
								<ul>
									<li><a href="#" title=""><i class="la la-car"></i><span>Cars</span></a></li>
									<li><a href="#" title=""><i class="la la-spoon"></i><span>Food & Drinks</span></a></li>
									<li><a href="#" title=""><i class="la la-plane"></i><span>Travels</span></a></li>
									<li><a href="#" title=""><i class="la la-briefcase"></i><span>Business</span></a></li>
									<li><a href="#" title=""><i class="la la-shopping-cart"></i><span>Shoppings</span></a></li>
								</ul>
							</div>
							<a class="arrow-down floating" href="#scroll-here" title=""><i class="la la-angle-down"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="scroll-here">
		<div class="block gray">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading">
							<h2>What Do You Want to Do Tonight?</h2>
							<span>Discover & connect with great local businesses in Toronto.</span>
						</div>
					</div>
					<div class="do-tonight-sec">
						<div class="row">
							<div class="col-md-8">
								<div class="row">
									<div class="col-md-12">
										<div class="dt-box">
											<a href="#" title=""><img src="http://placehold.it/751x285" alt="" /><span>Lodging</span></a>
										</div>
									</div>
									<div class="col-md-6">
										<div class="dt-box">
											<a href="#" title=""><img src="http://placehold.it/361x278" alt="" /><span>NIghtlIfe</span></a>
										</div>
									</div>
									<div class="col-md-6">
										<div class="dt-box">
											<a href="#" title=""><img src="http://placehold.it/361x278" alt="" /><span>Outdoors</span></a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="dt-box">
									<a href="#" title=""><img src="http://placehold.it/358x586" alt="" /><span>Adventure</span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray remove-top">
			<div class="row">
				<div class="col-md-12">
					<div class="heading">
						<h2>Recent Places</h2>
						<span>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</span>
					</div>
					<div class="listing-carousel">
						<div class="row" id="listing-carousel">
							<div class="col-md-3">
								<div class="listing-box">
									<div class="listing-box-thumb">
										<span class="price-list">$149.90</span>
										<img src="http://placehold.it/360x245" alt="" />
										<div class="listing-box-title">
											<h3><a href="#" title="">Sunpro Technology inc</a></h3>
											<span>Los Angeles /  Sillicon Valley </span>
											<span>(416) 551-0589</span>
										</div>
									</div>
									<div class="listing-rate-share">
										<div class="rated-list">
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star-o"></b>
											<b class="la la-star-o"></b>
											<span>(13)</span>
										</div>
										<span><i class="la la-share-alt"></i></span>
										<a href="#" title=""><i class="la la-heart-o"></i></a>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="listing-box">
									<div class="listing-box-thumb">
										<span class="price-list">$149.90</span>
										<img src="http://placehold.it/360x245" alt="" />
										<div class="listing-box-title">
											<h3><a href="#" title="">Evin Electronic Company</a></h3>
											<span>Los Angeles /  Sillicon Valley </span>
											<span>(416) 551-0589</span>
										</div>
									</div>
									<div class="listing-rate-share">
										<div class="rated-list">
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star-o"></b>
											<b class="la la-star-o"></b>
											<span>(13)</span>
										</div>
										<span><i class="la la-share-alt"></i></span>
										<a href="#" title=""><i class="la la-heart-o"></i></a>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="listing-box">
									<div class="listing-box-thumb">
										<span class="price-list">$149.90</span>
										<img src="http://placehold.it/360x245" alt="" />
										<div class="listing-box-title">
											<h3><a href="#" title="">Stand Up Show</a></h3>
											<span>Los Angeles /  Sillicon Valley </span>
											<span>(416) 551-0589</span>
										</div>
									</div>
									<div class="listing-rate-share">
										<div class="rated-list">
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star-o"></b>
											<b class="la la-star-o"></b>
											<span>(13)</span>
										</div>
										<span><i class="la la-share-alt"></i></span>
										<a href="#" title=""><i class="la la-heart-o"></i></a>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="listing-box">
									<div class="listing-box-thumb">
										<span class="price-list">$149.90</span>
										<img src="http://placehold.it/360x245" alt="" />
										<div class="listing-box-title">
											<h3><a href="#" title="">Bambi Planet Houseboat Bar& Grill </a></h3>
											<span>Los Angeles /  Sillicon Valley </span>
											<span>(416) 551-0589</span>
										</div>
									</div>
									<div class="listing-rate-share">
										<div class="rated-list">
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star-o"></b>
											<b class="la la-star-o"></b>
											<span>(13)</span>
										</div>
										<span><i class="la la-share-alt"></i></span>
										<a href="#" title=""><i class="la la-heart-o"></i></a>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="listing-box">
									<div class="listing-box-thumb">
										<span class="price-list">$149.90</span>
										<img src="http://placehold.it/360x245" alt="" />
										<div class="listing-box-title">
											<h3><a href="#" title="">Sunpro Technology inc</a></h3>
											<span>Los Angeles /  Sillicon Valley </span>
											<span>(416) 551-0589</span>
										</div>
									</div>
									<div class="listing-rate-share">
										<div class="rated-list">
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star"></b>
											<b class="la la-star-o"></b>
											<b class="la la-star-o"></b>
										</div>
										<span><i class="la la-share-alt"></i></span>
										<a href="#" title=""><i class="la la-heart-o"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray remove-top">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading">
							<h2>Quick and Easy Search</h2>
						</div>
					</div>
					<div class="col-md-12">
						<div class="services-sec">
							<div class="row">
								<div class="col-md-4">
									<div class="services">
										<i class="la la-paperclip"></i>
										<h3>Choose a Category</h3>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
									</div>
								</div>
								<div class="col-md-4">
									<div class="services">
										<i class="la la-map-marker"></i>
										<h3>Find Locations</h3>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
									</div>
								</div>
								<div class="col-md-4">
									<div class="services">
										<i class="la la-tencent-weibo"></i>
										<h3>Go Have Fun</h3>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block dark">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="counter-sec">
							<div class="counter">
								<i class="la la-file"></i>
								<h3>LISTINGS</h3>
								<span>108</span>
							</div>
							<div class="counter">
								<i class="la la-user"></i>
								<h3>USERS</h3>
								<span>675</span>
							</div>
							<div class="counter">
								<i class="la la-list"></i>
								<h3>LISTING TYPES</h3>
								<span>13</span>
							</div>
							<div class="counter">
								<i class="la la-folder-o"></i>
								<h3>CATEGORIES</h3>
								<span>45</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading">
							<h2>ArtIcles & TIps</h2>
							<span>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium <br />doloremque laudantium, totam rem aperiam.</span>
						</div>
						<div class="blog-sec">
							<div class="row">
								<div class="col-md-4">
									<div class="blog-post">
										<div class="blog-post-thumb"> <a href="#" title=""><img src="http://placehold.it/328x250" alt="" /></a></div>
										<div class="blog-detail">
											<ul class="blog-metas">
												<li><a href="#" title="">May 22, 2016</a></li>
												<li><a href="#" title="">Traveling</a></li>
												<li><a href="#" title="">by Jessica Moor</a></li>
											</ul>
											<h3><a href="#" title="">Top 15 Romantic Date Ideas for </a></h3>
											<p>Dating is a part of the human mating process whereby two people meet socially for…</p>
											<a href="#" title="">MORE</a>
										</div>
									</div><!-- BLog Post  -->
								</div>
								<div class="col-md-4">
									<div class="blog-post">
										<div class="blog-post-thumb"> <a href="#" title=""><img src="http://placehold.it/328x250" alt="" /></a></div>
										<div class="blog-detail">
											<ul class="blog-metas">
												<li><a href="#" title="">May 22, 2016</a></li>
												<li><a href="#" title="">Traveling</a></li>
												<li><a href="#" title="">by Jessica Moor</a></li>
											</ul>
											<h3><a href="#" title="">Tips for Top Quality Pics</a></h3>
											<p>Dating is a part of the human mating process whereby two people meet socially for…</p>
											<a href="#" title="">MORE</a>
										</div>
									</div><!-- BLog Post  -->
								</div>
								<div class="col-md-4">
									<div class="blog-post">
										<div class="blog-post-thumb"> <a href="#" title=""><img src="http://placehold.it/328x250" alt="" /></a></div>
										<div class="blog-detail">
											<ul class="blog-metas">
												<li><a href="#" title="">May 22, 2016</a></li>
												<li><a href="#" title="">Traveling</a></li>
												<li><a href="#" title="">by Jessica Moor</a></li>
											</ul>
											<h3><a href="#" title="">Tips for Top Quality Pics</a></h3>
											<p>Dating is a part of the human mating process whereby two people meet socially for…</p>
											<a href="#" title="">MORE</a>
										</div>
									</div><!-- BLog Post  -->
								</div>
							</div>
							<a href="#" title="" class="view-all-blog">View Blog</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray remove-top">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading">
							<h2>CATEGORIES</h2>
							<span>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium <br />doloremque laudantium, totam rem aperiam.</span>
						</div>
						<div class="categories-sec">
							<div class="row">
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-briefcase"></i></span>
											<h3><a href="#" title="">Business</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-car"></i></span>
											<h3><a href="#" title="">Cars</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-bed"></i></span>
											<h3><a href="#" title="">Hotels</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-spoon"></i></span>
											<h3><a href="#" title="">Food & Drinks</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-shopping-cart"></i></span>
											<h3><a href="#" title="">Shoppings</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-book"></i></span>
											<h3><a href="#" title="">Educations</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-briefcase"></i></span>
											<h3><a href="#" title="">Jobs</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
								<div class="col-md-3 col-sm-4 col-xs-12">
									<div class="category-box">
										<a href="#" title=""><img src="http://placehold.it/262x198" alt="" /></a>
										<div class="category-box-detail">
											<span><i class="la la-plane"></i></span>
											<h3><a href="#" title="">Travels</a></h3>
											<p>8 listings</p>
										</div>
									</div><!-- Category Box -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray remove-top">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="client-sec">
							<div class="row">
								<div class="col-md-3 col-sm-6 col-xs-6">
									<div class="client-box">
										<a href="#" title=""><img src="http://placehold.it/232x75" alt="" /></a>
									</div><!-- Client Box -->
								</div>
								<div class="col-md-3 col-sm-6 col-xs-6">
									<div class="client-box">
										<a href="#" title=""><img src="http://placehold.it/232x75" alt="" /></a>
									</div><!-- Client Box -->
								</div>
								<div class="col-md-3 col-sm-6 col-xs-6">
									<div class="client-box">
										<a href="#" title=""><img src="http://placehold.it/232x75" alt="" /></a>
									</div><!-- Client Box -->
								</div>
								<div class="col-md-3 col-sm-6 col-xs-6">
									<div class="client-box">
										<a href="#" title=""><img src="http://placehold.it/232x75" alt="" /></a>
									</div><!-- Client Box -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block gray remove-top">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="subscribe-sec">
							<i class="la la-envelope-o"></i>
							<p>Subscribe and be notified about new locations</p>
							<form>
								<input type="text" placeholder="Your Mail" />
								<button type="submit"><i class="la la-angle-right"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer>
		<div class="block remove-bottom">
			<div data-velocity="-.1" style="background: url(http://placehold.it/1920x800) repeat scroll 50% 422.28px transparent;" class="parallax no-parallax scrolly-invisible"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-4 column">
						<div class="widget">
							<h3 class="footer-title">PROLIST THEME</h3>
							<div class="about-widget">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscingelit. Nulla ultrices nisi vitae laoreet dapibus. Etiampulvinar non justo at tincidunt. Cras turpis erat, ornare eget sem ut, tempus scelerisque lorem.</p>
								<ul>
									<li><a href="#" title=""><i class="la la-twitter"></i></a></li>
									<li><a href="#" title=""><i class="la la-instagram"></i></a></li>
									<li><a href="#" title=""><i class="la la-pinterest"></i></a></li>
									<li><a href="#" title=""><i class="la la-google-plus"></i></a></li>
									<li><a href="#" title=""><i class="la la-tumblr "></i></a></li>
								</ul>
							</div>
						</div><!-- Widget -->
					</div>
					<div class="col-md-4 column">
						<div class="widget">
							<h3 class="footer-title">PROLIST CATEGORIES</h3>
							<div class="link-widget">
								<ul>
									<li><a href="#" title="">Food & Drink</a></li>
									<li><a href="#" title="">IT World</a></li>
									<li><a href="#" title="">Money & Finance</a></li>
									<li><a href="#" title="">Movies & Cinemas</a></li>
									<li><a href="#" title="">Sports</a></li>
									<li><a href="#" title="">Music</a></li>
									<li><a href="#" title="">Parties</a></li>
									<li><a href="#" title="">People & Health</a></li>
									<li><a href="#" title="">Seminars</a></li>
									<li><a href="#" title="">Theatres</a></li>
								</ul>
							</div>
						</div><!-- Widget -->
					</div>
					<div class="col-md-4 column">
						<div class="widget">
							<h3 class="footer-title">CONTACT INFORMATION</h3>
							<div class="contact-widget">
								<ul>
									<li>
										<i class="la la-map"></i>
										<span>Address</span>
										<span>Proudly Made in Canada & USA</span>
									</li>
									<li>
										<i class="la la-mobile"></i>
										<span>Cell Phone</span>
										<span>+0-456-098-789, +1-456-789-123</span>
									</li>
									<li>
										<i class="la la-envelope"></i>
										<span>E-mail Address</span>
										<span><a href="mailto:info@prolist.com">info@prolist.com</a>, <a href="mailto:support@prolist.com">support@prolist.com</a></span>
									</li>
								</ul>
							</div>
						</div><!-- Widget -->
					</div>
				</div>
			</div>
			<div class="bottom-line">
				<span>Copyright Prolist © 2017. All Rights Reserved</span>
			</div>
		</div>
	</footer>

	<div class="account-popup-sec">
		<div class="acount-popup login-popup">
			<span class="close-popup"><i class="la la-close"></i></span>
			<h3>LOGIN</h3>
			<form>
				<div class="field-form">
					<input class="effect-16" type="text" placeholder="">
		            <label>Username or email address</label>
		            <span class="focus-border"></span>
				</div>
				<div class="field-form">
					<input class="effect-16" type="password" placeholder="">
		            <label>Password</label>
		            <span class="focus-border"></span>
				</div>
				<p>
					<input class="styled-checkbox" id="styled-checkbox-1" type="checkbox" value="value1">
    				<label for="styled-checkbox-1">Remember me</label>
				</p>
				<a href="#" title="">Lost your password</a>
				<button type="submit">LOGIN</button>
				<div class="extra-login">
					<span>Or</span>
					<ul>
						<li class="connect-fb"><a href="#" title=""><i class="la la-facebook"></i> Facebook Connect</a></li>
						<li class="connect-twitter"><a href="#" title=""><i class="la la-twitter"></i> Twitter Connect</a></li>
					</ul>
				</div>
			</form>
		</div>
		<div class="acount-popup register-popup">
			<span class="close-popup"><i class="la la-close"></i></span>
			<h3>REGISTER</h3>
			<form>
				<div class="field-form">
					<input class="effect-16" type="text" placeholder="">
		            <label>First Name</label>
		            <span class="focus-border"></span>
				</div>
				<div class="field-form">
					<input class="effect-16" type="text" placeholder="">
		            <label>Last Name</label>
		            <span class="focus-border"></span>
				</div>
				<div class="field-form">
					<input class="effect-16" type="text" placeholder="">
		            <label>Email</label>
		            <span class="focus-border"></span>
				</div>
				<div class="field-form">
					<input class="effect-16" type="password" placeholder="">
		            <label>Password</label>
		            <span class="focus-border"></span>
				</div>
				<div class="field-form">
					<input class="effect-16" type="password" placeholder="">
		            <label>Confirm Password</label>
		            <span class="focus-border"></span>
				</div>
				<button type="submit">REGISTER NOW</button>
				<p>By clicking on “Register Now” button you are accepting the <a href="#" title="">Terms & Conditions</a> </p>
			</form>
		</div>
	</div>

</div>

<!-- Script -->
<script type="text/javascript" src="js/modernizr.js"></script><!-- Modernizer -->
<script type="text/javascript" src="js/jquery-2.1.1.js"></script><!-- Jquery -->
<script type="text/javascript" src="js/script.js"></script><!-- Script -->
<script type="text/javascript" src="js/bootstrap.min.js"></script><!-- Bootstrap -->
<script type="text/javascript" src="js/scrolltopcontrol.js"></script><!-- ScrollTopControl -->
<script type="text/javascript" src="js/slick.min.js"></script><!-- Slick -->
<script type="text/javascript" src="js/scrolly.js"></script><!-- Slick -->
<script type="text/javascript" src="js/sumoselect.js"></script><!-- Nice Select -->
<script type="text/javascript" src="js/choosen.min.js"></script><!-- Nice Select -->
<script type="text/javascript" src="js/waypoints.js"></script><!-- Nice Select -->

</body>
</html>
<?php /**PATH C:\xampp\htdocs\photoshow\resources\views/index.blade.php ENDPATH**/ ?>