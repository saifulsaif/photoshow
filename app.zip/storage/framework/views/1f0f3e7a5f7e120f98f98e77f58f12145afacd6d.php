<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<section>
		<div class="block gray remove-top">
			<div class="row">
				<div class="col-md-12">
					<div class="list-detail-sec">
						<ul class="list-detail-carousel" id="listing-detail-carousel">
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld1.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
				              <form>
				                <div class="field"><input type="text" placeholder="Keywords"></div>

				                <div class="field">
				                  <select data-placeholder="All Categories" class="chosen-select" tabindex="2">
				                          <option value="All Categories">All Categories</option>
				                          <option value="Foods">Foods</option>
				                          <option value="Lodging">Lodging</option>
				                          <option value="Nightlife">Nightlife</option>
				                          <option value="AOutdoors">Outdoors</option>
				                          <option value="Restaurants">Restaurants</option>
				                      </select>
				                </div>
				                <div class="field">
				                  <button type="submit"><i class="la la-search"></i>SEARCH</button>
				                </div>
				              </form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld2.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
				              <form>
				                <div class="field"><input type="text" placeholder="Keywords"></div>
				                <div class="field">
				                  <select data-placeholder="All Locations" class="chosen-select" tabindex="2">
				                          <option value="All Locations">All Locations</option>
				                          <option value="United States">United States</option>
				                          <option value="United Kingdom">United Kingdom</option>
				                          <option value="Afghanistan">Afghanistan</option>
				                          <option value="Aland Islands">Aland Islands</option>
				                          <option value="Albania">Albania</option>
				                      </select>
				                </div>
				                <div class="field">
				                  <select data-placeholder="All Categories" class="chosen-select" tabindex="2">
				                          <option value="All Categories">All Categories</option>
				                          <option value="Foods">Foods</option>
				                          <option value="Lodging">Lodging</option>
				                          <option value="Nightlife">Nightlife</option>
				                          <option value="AOutdoors">Outdoors</option>
				                          <option value="Restaurants">Restaurants</option>
				                      </select>
				                </div>
				                <div class="field">
				                  <button type="submit"><i class="la la-search"></i>SEARCH</button>
				                </div>
				              </form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
							<li>
								<div class="list-detail-box">
									<img src="<?php echo e(asset('images/slider/ld3.jpg')); ?>" alt="" />
									<div class="list-detail-info">
										<div class="directory-searcher" style="height: 60px;">
				              <form>
				                <div class="field"><input type="text" placeholder="Keywords"></div>
				                <div class="field">
				                  <select data-placeholder="All Locations" class="chosen-select" tabindex="2">
				                          <option value="All Locations">All Locations</option>
				                          <option value="United States">United States</option>
				                          <option value="United Kingdom">United Kingdom</option>
				                          <option value="Afghanistan">Afghanistan</option>
				                          <option value="Aland Islands">Aland Islands</option>
				                          <option value="Albania">Albania</option>
				                      </select>
				                </div>
				                <div class="field">
				                  <select data-placeholder="All Categories" class="chosen-select" tabindex="2">
				                          <option value="All Categories">All Categories</option>
				                          <option value="Foods">Foods</option>
				                          <option value="Lodging">Lodging</option>
				                          <option value="Nightlife">Nightlife</option>
				                          <option value="AOutdoors">Outdoors</option>
				                          <option value="Restaurants">Restaurants</option>
				                      </select>
				                </div>
				                <div class="field">
				                  <button type="submit"><i class="la la-search"></i>SEARCH</button>
				                </div>
				              </form>
				            </div>
										<h3>FIND YOUR BEST HERE.....</h3>
										<span></span>
										<span></span>
										<p></p>
										<div class="rated-list">

										</div>
										<ul class="list-detail-metas">

										</ul>
									</div>
								</div>
							</li>
						</ul>
						<div class="mian-listing-detail">
							<div class="container">
								<div class="row">
									<div class="col-md-12 column">
										<div class="row">
										 <div class="do-tonight-sec">
											 <div class="row" style="margin-top:65px;">
														 <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														 <div class="col-md-4">
															 <div class="dt-box">
																 <a href="<?php echo e(route('photos',$photo->id)); ?>" title=""><img src="<?php echo e($photo->photo); ?>" alt="" /><span><?php echo e($photo->title); ?></span></a>
															 </div>
														 </div>
														 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											 </div>
										 </div>
									 </div>
									</div>
								</div>
								<div class="pagination">
									<ul>
										<li class="prev"><a href=""><i class="la  la-arrow-left"></i></a></li>
										<li><a href="">1</a></li>
										<li><a class="active" href="">2</a></li>
										<li><a href="">3</a></li>
										<li><span class="delimeter">...</span></li>
										<li><a href="">22</a></li>
										<li class="next"><a href=""><i class="la  la-arrow-right"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/photos.blade.php ENDPATH**/ ?>