<?php $__env->startSection('content'); ?>

<div class="data-table-area">
       <div class="container">
           <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <div class="data-table-list">
                       <div class="basic-tb-hd">
                           <h2>All Images</h2>
                             <?php if(Session::has('danger')): ?>
                             <div class="alert alert-danger">
                               <p><?php echo e(Session::get('danger')); ?></p>
                             </div>
                           <?php endif; ?>
                           <?php if(Session::has('success')): ?>
                             <div class="alert alert-success">
                               <p><?php echo e(Session::get('success')); ?></p>
                             </div>
                           <?php endif; ?>
                           <p style="margin-bottom: 0px;float: right;color: white;"><button class="btn notika-btn-teal waves-effect"data-toggle="modal" data-target="#myModaltwo"><i class="notika-icon notika-plus"></i>Add</button>

                           </p>
                       </div>
                          <div class="modal fade" id="myModaltwo" role="dialog">
                                    <div class="modal-dialog modal-sm">
                                        <form action="<?php echo e(route('save.photo')); ?>" method="post" enctype="multipart/form-data">
                  											   <?php echo e(csrf_field()); ?>

                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <h2>Add  Image</h2>
                                                <div class="row">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group float-lb">
                                                            <div class="nk-int-st">
                                                              <select style="width:100%;" name="category_id">
                                                              <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                              </div>
                                                        </div>
                                                        <div class="form-group float-lb">
                                                            <div class="nk-int-st">
                                                                <input name="title" placeholder="Title" type="text" class="form-control">
                                                              </div>
                                                        </div>
                                                        <div class="form-group float-lb">
                                                            <div class="nk-int-st">
                                                                <input name="photo" type="file" class="form-control">
                                                              </div>
                                                        </div>
                                                        <div class="form-group float-lb">
                                                          <div class="table-responsive">
                                                               <table class="table table-bordered" id="dynamic_field">
                                                                    <tr>
                                                                         <td><input type="text" name="tag[]" placeholder="Enter New Tag" class="form-control name_list" /></td>
                                                                         <td><button type="button" name="add" id="add" class="btn btn-success">Add Tag</button></td>
                                                                    </tr>
                                                               </table>
                                                          </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                </div>
                                            <div class="modal-footer">
                                                 <button class="btn btn-success notika-btn-success">Save</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                  </form>
                                </div>

                       <div class="table-responsive">
                           <table id="data-table-basic" class="table table-striped">
                               <thead>
                                   <tr>
                                       <th>S/L</th>
                                       <th>Date</th>
                                       <th>Author</th>
                                       <th>Category</th>
                                       <th>Title</th>
                                       <th>Tags</th>
                                       <th> Image</th>
                                       <th>Option</th>
                                   </tr>
                               </thead>
                               <tbody>
                                 <?php $i=1; ?>
                                 <?php $__currentLoopData = $all_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($i++); ?></td>
                                       <td><?php echo e($photo->created_at); ?></td>
                                       <td>
                                          <?php
                                          $photos = \DB::table('profiles')->find(1);
                                          $cat = \DB::table('categories')->find(1);
                                          ?>
                                            <img style="border-radius: 50%;height: 55px;width: 55px;margin-top: 16px;margin-left: 10px" src="<?php echo e(asset($photos->photo)); ?>" alt="">
                                       </td>
                                       <td><?php echo e($cat->name); ?></td>
                                       <td><?php echo e($photo->title); ?></td>
                                        <td>
                                        <?php
                                          $tags = \DB::table('tags')->where('photo_id',$photo->id)->get();

                                        ?>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <p><?php echo e($tag->tag); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </td>
                                       <td><img  style="background-color:#00c292;" src="<?php echo e(asset($photo->photo)); ?>" alt="" /></td>
                                       <td><button style="background: #00BCD4;color:white;" class="btn notika-btn-teal waves-effect"data-toggle="modal" data-mytitle="<?php echo e($photo->id); ?>" id="edit"  data-target="#myModalthree"><i class="notika-icon notika-edit"></i></button>
                                        <a href="<?php echo e(route('delete.photo', $photo->id)); ?>"> <button class="btn btn-danger danger-icon-notika waves-effect"><i class="notika-icon notika-trash"></i></button></td>
                                   </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                           <div class="pagination">

                              <ul>
                                  <span style="color:red;"><?php echo e($all_photos->links()); ?></span>
                              </ul>
                            </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>

   <script>

     $('#edit').on('show.bs.modal', function (event) {
         var button = $(event.relatedTarget)
         var title = button.data('mytitle')
         console.log(title);

         var modal = $(this)
         modal.find('.modal-body #title').val(title);
         modal.find('.modal-body #des').val(description);
         modal.find('.modal-body #cat_id').val(cat_id);
   })
   </script>
   <script>
 $(document).ready(function(){
      var i=1;
      $('#add').click(function(){
           i++;
           $('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="tag[]" placeholder="Enter your Name" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
      });
      $(document).on('click', '.btn_remove', function(){
           var button_id = $(this).attr("id");
           $('#row'+button_id+'').remove();
      });
      $('#submit').click(function(){
           $.ajax({
                url:"name.php",
                method:"POST",
                data:$('#add_name').serialize(),
                success:function(data)
                {
                     alert(data);
                     $('#add_name')[0].reset();
                }
           });
      });
 });
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/admin/all_photo.blade.php ENDPATH**/ ?>