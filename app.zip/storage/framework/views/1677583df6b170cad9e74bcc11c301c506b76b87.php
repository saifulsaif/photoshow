

<?php $__env->startSection('content'); ?>
<div class="form-element-area">
       <div class="container">
         <form action="<?php echo e(route('update.terms')); ?>" method="post" enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>


           <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <?php if(Session::has('danger')): ?>
                   <div class="alert alert-danger">
                     <p><?php echo e(Session::get('danger')); ?></p>
                   </div>
                 <?php endif; ?>
                 <?php if(Session::has('success')): ?>
                   <div class="alert alert-success">
                     <p><?php echo e(Session::get('success')); ?></p>
                   </div>
                 <?php endif; ?>
                   <div class="form-element-list">
                       <div class="basic-tb-hd">
                           <h2>Update Terms And Conditions </h2>
                         </div>

                         <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <div class="nk-int-st">
                                             <input type="hidden" name="id" value="<?php echo e($terms->id); ?>">
                                            <textarea style=" padding-left: 21px;" name="text" class="form-control" rows="40"><?php echo e($terms->text); ?></textarea>

                                        </div>
                                    </div>
                                </div>
                            </div>

                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="float:right;">
                             <div class="form-example-int">
                                 <button class="btn btn-success notika-btn-success">Update</button>
                             </div>
                         </div>
                      </div>
               </div>
           </div>

        </form>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/freedownload/public_html/resources/views/admin/terms.blade.php ENDPATH**/ ?>