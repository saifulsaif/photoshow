<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<section>
	<div class="block gray ">
		<div class="container">
			<div class="row">
				<?php if(Session::has('danger')): ?>
				  <div class="alert alert-danger">
				    <p><?php echo e(Session::get('danger')); ?></p>
				  </div>
				<?php endif; ?>
				<?php if(Session::has('success')): ?>
				  <div class="alert alert-success">
				    <p><?php echo e(Session::get('success')); ?></p>
				  </div>
				<?php endif; ?>
				<div class="col-md-12 column">
					<div class="shoping-detail-sec">
						<div class="row">
							<div class="col-md-9 col-ms-6">
								<div class="row">
									<div class="col-md-4 col-ms-4" style="text-align:center;">
										<?php
										$author_photo= App\Profile::where('user_id',$id)->first();
										?>
										<!-- <?php echo e(url('/user/profile')); ?>/<?php echo e($author_photo->user_id); ?> -->
										<div class="review-avatar"> <a href="<?php echo e(url('/author-profile')); ?>/<?php echo e($author_photo->id); ?>"> <img style="border-radius: 50%;height: 176px;width: 176px;" src="<?php echo e(asset('/'.$author_photo->photo)); ?>" alt=""> </a></div>

										<h4 style="font-size: 24px;margin: 16px;"><?php echo e($author_photo->first_name); ?><?php echo e($author_photo->last_name); ?></h4>
										<div class="social">
											<div class="shop-share">
												<span>Social Media </span>
												<a href="<?php echo e($author_photo->twitter); ?>" title=""><i class="la la-twitter"></i></a>
												<a href="<?php echo e($author_photo->youtube); ?>" title=""><i class="la la-youtube"></i></a>
												<a href="<?php echo e($author_photo->linkin); ?>" title=""><i class="la la-linkedin"></i></a>
												<a href="<?php echo e($author_photo->facebook); ?>" title=""><i class="la la-facebook"></i></a>
											</div>
										</div>
									</div>
									<div class="col-md-2 col-ms-4">
										 <h5>Follower</h5>
										 <?php if($followers>1000): ?>
                       <?php $followers=($followers/1000); ?>
											 <span style="margin-left: 13px;"><?php echo e($followers); ?>K	 Follows</span>
										 <?php else: ?>
										 <span style="margin-left: 13px;"><?php echo e($followers); ?></span>
										 <?php endif; ?>
									</div>
									<div class="col-md-2 col-ms-4">

										<h5>Following</h5>
										<?php if($following>1000): ?>
											<?php $following=($following/1000); ?>
											<span style="margin-left: 13px;"><?php echo e($following); ?>K</span>
										<?php else: ?>
										<span style="margin-left: 13px;"><?php echo e($following); ?></span>
										<?php endif; ?>

									</div>
									<div class="col-md-2 col-ms-4">

										<h5> Upload</h5>
											<span style="margin-left: 13px;"><?php echo e($upload); ?></span>

									</div>
									<!-- <div class="col-md-2 col-ms-4">

										<h5> Download</h5>

									</div> -->
								</div>
								<div class="single-product-gallery">
								</div>
							</div>
							<div class="col-md-3 col-ms-6">
								<div class="single-product-info-a">
									<button type="button" id="button" class="follow">Follow</button>
								</div>
							</div>
							<div class="col-md-12 column">

								<div class="filter-bar">
									<span style="color: #1c2027;float: left;font-family: Roboto;font-size: 15px;margin: 11px 0;font-weight: 500;">Upload Photos</span>
								</div>
						<div class="product-sec">
							<div class="products-box">
								<div class="row">


									<div class="col-md-3 col-sm-6 col-xs-12">
										<?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($photo->id%4==0): ?>
										<div class="product-box">
											<div class="product-thumb">
												<img src="<?php echo e('http://www.freedownloadimage.com/'.$photo->photo); ?>" alt="" />

											</div>
											<h3><a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><?php echo e($photo->title); ?></a></h3>
										</div>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="col-md-3 col-sm-6 col-xs-12">
									<?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($photo->id%4==1): ?>
										<div class="product-box">
											<div class="product-thumb">
												<img src="<?php echo e('http://www.freedownloadimage.com/'.$photo->photo); ?>" alt="" />

											</div>
											<h3><a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><?php echo e($photo->title); ?></a></h3>
										</div>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="col-md-3 col-sm-6 col-xs-12">
									<?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($photo->id%4==2): ?>
										<div class="product-box">
											<div class="product-thumb">
												<img src="<?php echo e('http://www.freedownloadimage.com/'.$photo->photo); ?>" alt="" />

											</div>
											<h3><a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><?php echo e($photo->title); ?></a></h3>
										</div>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="col-md-3 col-sm-6 col-xs-12">
									<?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($photo->id%4==3): ?>
										<div class="product-box">
											<div class="product-thumb">
												<img src="<?php echo e('http://www.freedownloadimage.com/'.$photo->photo); ?>" alt="" />

											</div>
											<h3><a href="<?php echo e(url('/photos/view')); ?>/<?php echo e($photo->id); ?>/<?php echo e($photo->category_id); ?>" title=""><?php echo e($photo->title); ?></a></h3>
										</div>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
							<div class="pagination">

								<ul>
										<span style="color:red;"><?php echo e($related_photos->links()); ?></span>
								</ul>
							</div>
						</div>
					</div>
						</div>
					</div><!-- Shoping Detail Sec -->
				</div>
			</div>
		</div>
	</div>
</section>
<script>
			$(document).on('click', '#button', function(e){
			$.ajax({
				alert('work');

			});
			});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photoshow\resources\views/fontend/author-profile.blade.php ENDPATH**/ ?>