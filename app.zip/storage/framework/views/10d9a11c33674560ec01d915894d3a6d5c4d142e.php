
<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

	<section>
		<div class="block gray ">
			<div class="container">
				<div class="row">
					<div class="col-md-12 column">
						<h3 class="mini-title">Latest News And Promition</h3>
						<div class="grids-listings">
							<div class="row">
								<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 col-sm-6 col-xs-12">
									<div class="listing-box">
										<div class="listing-box-thumb">
											<span class="price-list">New</span>
											<img src="<?php echo e($pro->photo); ?>" alt="" />
											<div class="listing-box-title">
												<!-- <h3><a href="#" title=""><?php echo e($pro->title); ?></a></h3> -->
												<!-- <span>Los Angeles /  Sillicon Valley </span>	 -->
												<span><?php echo e($pro->title); ?> </span>
											</div>
										</div>
										<div class="listing-rate-share">
											<div class="rated-list">
											<a target="_blank" href="<?php echo e($pro->link); ?>">	<span><?php echo e($pro->link); ?></span></a>
											</div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<div class="pagination">
							<ul>
								<li class="prev"><a href=""><i class="la  la-arrow-left"></i></a></li>
								<li><a href="">1</a></li>
								<li><a class="active" href="">2</a></li>
								<li><a href="">3</a></li>
								<li><span class="delimeter">...</span></li>
								<li><a href="">22</a></li>
								<li class="next"><a href=""><i class="la  la-arrow-right"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/freedownload/public_html/resources/views/fontend/promotion.blade.php ENDPATH**/ ?>