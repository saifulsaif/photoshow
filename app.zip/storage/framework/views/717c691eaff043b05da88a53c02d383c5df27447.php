
<?php echo $__env->make('fontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

	<section>
		<div class="block gray ">
			<div class="container">
				<div class="row">
					<div class="col-md-12 column">
						<div class="terms-sec">
							<h3 class="mini-title">Privacy And Policy</h3>
							<div class="terms">
							<?php echo'<div class="terms">'.$policy->text.'</div>'; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/freedownload/public_html/resources/views/fontend/policy.blade.php ENDPATH**/ ?>